﻿namespace ShortFuze.Core
{
    public enum StatusTypes
    {
        None,
        Active,
        Inactive,
        Deleted
    }
}
