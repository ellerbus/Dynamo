﻿namespace ShortFuze.Core
{
    public enum SecurityRequest
    {
        None, View, Update, Delete
    }
}
