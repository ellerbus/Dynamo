
create procedure dbo.BeerSelectMany
as

select	*
from	dbo.Beer

go
